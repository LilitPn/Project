import { Component, OnInit } from '@angular/core';
import { DataService } from 'src/app/service/data.service';
import { User } from 'src/app/shared/models/users.interfaces';
import { UserService } from '../../service/user.service';

@Component({
  selector: 'user-detail',
  templateUrl: './user-detail.component.html',
  styleUrls: ['./user-detail.component.css']
})
export class UserDetailComponent implements OnInit {
 public user: User = new User();

  constructor(private _userService: UserService) { }

  ngOnInit(): void {
    this._userService.userData.subscribe(data => { this.user = data; console.log(data) });
  }
}
