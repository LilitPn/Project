import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataService } from 'src/app/service/data.service';
import { Post, User } from 'src/app/shared/models/users.interfaces';
import { UserService } from '../../service/user.service';




@Component({
  selector: 'user-list',
  templateUrl: './user-list.component.html',
  styleUrls: ['./user-list.component.css']
})
export class UserListComponent implements OnInit {
  userPosts: Array<Array<Post>> = new Array<Array<Post>>();
  public users: Array<User> = new Array<User>();

  constructor(
    private _dataService: DataService,
    private _userService: UserService,
    private _router: Router
  ) { }

  ngOnInit(): void {
    this._dataService.usersData.subscribe(data => { this.users = data; console.log(data) });
  }

  showDetails(user: User): void {
    this._userService.setUserData(user);
    this._router.navigateByUrl(`users/posts/${user.id}`);
  }
}
