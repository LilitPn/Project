import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import { User } from 'src/app/shared/models/users.interfaces';

@Injectable()
export class UserService {
  public userData: Subject<User> = new Subject<User>();

  constructor() { }

  setUserData(userData: User): void {
    this.userData.next(userData);
  }
}
