import { Component, OnInit } from '@angular/core';
import { Post, User } from 'src/app/shared/models/users.interfaces';
import { DataService } from 'src/app/service/data.service';
import { Router } from '@angular/router';




@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  
  }

}